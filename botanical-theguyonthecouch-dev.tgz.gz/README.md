# README
[<img src="https://open.autocode.com/static/images/open.svg?" width="192">](https://open.autocode.com/)

This is the README for your project. If you choose to publish an open source `app`
for this project, this is what will be displayed on [Autocode Apps](/app).
**The first line** will be used as the title of the app. Otherwise, you should use it
to record important information about the project for yourself or your teammates.

## Preview
While in the Autocode Editor, you can see a small preview of your README
in the bottom right corner. Click on it to expand the preview.

## GitHub
Should you decide to publish your projects and templates to GitHub,
you can include an **Open in Autocode** button as displayed above.
This will enable anybody to fork your project in Autocode directly.