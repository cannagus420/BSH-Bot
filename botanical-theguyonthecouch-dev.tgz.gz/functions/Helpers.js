module.exports.canEdit = function (context, lib) {

};
