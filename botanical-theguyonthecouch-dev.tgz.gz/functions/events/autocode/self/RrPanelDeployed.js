const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

await lib.discord.commands['@0.0.0'].create({
  guild_id: process.env.GUILD_ID,
  name: 'create-reaction-role',
  description: 'Creates a reaction role panel (Admin Only)',
  options: [
    {
      type: 8,
      name: 'role',
      description: 'The role you want users to toggle on/off',
      required: true,
    },
    {
      type: 3,
      name: 'name',
      description: 'The name of the role',
      required: true,
    },
    {
      type: 3,
      name: 'description',
      description: 'Description of what the role does.',
      required: true,
    },
    {
      type: 3,
      name: 'hex',
      description:
        '(DO NOT INCLUDE THE #) The hex code for the color on the reaction role panel.',
      required: true,
    },
    {
      type: 3,
      name: 'emoji',
      description: 'Emoji that bests describes the role.',
      required: true,
    },
    {
      type: 7,
      name: 'channel',
      description: 'The channel to send this reaction role panel in.',
      required: true,
    },
  ],
});
